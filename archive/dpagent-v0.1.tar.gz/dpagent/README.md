# dpagent

AI agent that installs open-source data stacks on Linux servers, driven by markdown skill files. Provider-agnostic — works with any LLM via LiteLLM (Gemini free tier, Groq free, OpenAI, Anthropic, local Ollama).

## Quick start (test the flow in ~5 minutes)

You can test the **planning** step from any laptop — no server needed. Only `apply` needs a real target.

```bash
# 1. Get a free LLM API key. Recommended: Google Gemini (very generous free tier)
#    https://aistudio.google.com/app/apikey

# 2. Clone + install
git clone <your-repo>/dpagent.git
cd dpagent
python3 -m venv .venv && source .venv/bin/activate
pip install -e .

# 3. Configure the LLM
cp .env.example .env
# edit .env — set GEMINI_API_KEY (or GROQ_API_KEY, or OPENAI_API_KEY, etc.)
export $(grep -v '^#' .env | xargs)

# 4. Sanity check — doesn't call the LLM
dpagent info

# 5. Plan (safe — this WON'T touch your system, just calls the LLM)
#    --fake-os lets you test off-target (from a Mac/Windows dev machine)
dpagent plan examples/postgres-only.yaml --fake-os ubuntu
```

You should see a tree of shell steps the LLM produced. That's the whole planning loop working.

## Apply on a throwaway VM

Once planning looks good, ssh into a test VM (Ubuntu 22.04 or Oracle Linux 8/9), clone the repo, and:

```bash
export DPAGENT_MODEL=gemini/gemini-2.0-flash
export GEMINI_API_KEY=...

dpagent plan examples/postgres-only.yaml
dpagent apply --dry-run    # prints commands but runs nothing
sudo -E dpagent apply       # runs for real
```

If a step fails, `apply` halts and marks it failed. Fix the issue (or edit the skill) and re-run — it resumes from the failed step (checkpointing via SQLite in `~/.local/share/dpagent/state.db`).

## Architecture

Five modules, one target OS at a time:

- **agent-core** (`cli.py`) — orchestrator, click commands, pretty output.
- **planner** (`planner.py`) — reads spec + skills + OS, prompts the LLM, parses plan JSON.
- **bash-executor** (`bash_executor.py`) — subprocess wrapper with dry-run, timeout, structured log.
- **guardrails** (`guardrails.py`) — whitelist prefixes (auto-allowed) + blacklist patterns (refused always).
- **os-detector** (`os_detector.py`) — reads `/etc/os-release`, chooses `apt` vs `dnf`, etc.
- **state-store** (`state_store.py`) — SQLite plan + step + checkpoint journal.
- **skill-library** (`skills/*.md`) — one markdown file per component; 6 sections (trigger, prerequisites, install debian, install rhel, config, verify, rollback).
- **llm** (`llm.py`) — provider-agnostic wrapper around LiteLLM.

## Adding a new component

1. `cp skills/_template.md skills/<name>.md`
2. Fill in the 6 sections for both debian and rhel families.
3. Reference `<name>` in a `project.yaml` under `components:`.
4. `dpagent plan project.yaml` — the planner picks it up automatically.

Test skill quality by running plan repeatedly and reading the JSON output. Bad skill → bad plan.

## Guardrails

Every command runs through `guardrails.check()`. Three verdicts:

| Verdict | Meaning | Action |
|---|---|---|
| `whitelisted` | Matches a known-safe prefix (`apt`, `dnf`, `systemctl`, `sudo -u postgres`, ...) | runs without asking |
| `needs_confirm` | Not in whitelist, not in blacklist | asks the user Y/n |
| `blocked` | Matches a blacklist regex (`rm -rf /`, `dd of=/dev/sd*`, `mkfs.*`, `curl \| bash`, reboot, ...) | refused, plan halts |

Extend the lists in `dpagent/guardrails.py`. Run `pytest tests/` to verify.

## Cost

Rough estimate per `plan` call, assuming one skill (~200 lines):

| Provider | Cost |
|---|---|
| Gemini 2.0 Flash (free tier) | $0 |
| Groq Llama 3.3 70B (free tier) | $0 |
| Ollama local | $0 (electricity) |
| OpenAI gpt-4o-mini | ~$0.005 |
| Claude Sonnet 4.5 | ~$0.20 |

Full stack (5+ skills) is 5-10x. Cache and re-use skill content where you can.

## Roadmap

- **v0.1** (this): plan + apply happy path + guardrails + 1 skill
- **v0.2**: verify command (parse skills' verify section), auto-retry with LLM on step failure
- **v0.3**: skills for airflow, dbt, clickhouse (full ETL stack)
- **v0.4**: skills for minio, trino, spark, iceberg, hive-metastore (lakehouse stack)
- **v0.5**: rollback command, LVM snapshot before install, secret handling via env/vault
- **v0.6**: web UI for reviewing plans, packaged as `pyinstaller` binary
