# <component-name>

## trigger
When to use this skill — e.g. "when project.yaml lists `<component>` in components".

## prerequisites
- packages that must be present first
- ports that must be open
- users or groups that must exist
- other skills that must run before this one

## install (debian)
Shell steps for Debian/Ubuntu. One command per line, small idempotent chunks.

```bash
apt update
apt install -y <package>
systemctl enable --now <service>
```

## install (rhel)
Shell steps for RHEL / Oracle Linux / Rocky / AlmaLinux / Fedora.

```bash
dnf install -y <package>
systemctl enable --now <service>
```

## config
Config file templates. Use Jinja2-style `{{ var }}` where values come from the spec.
Show the full file inline so the planner can render it in one step.

## verify
Commands that pass (exit 0) when the install is healthy.

```bash
systemctl is-active <service>
<binary> --version
```

## rollback
Commands to fully uninstall.

```bash
systemctl disable --now <service>
apt remove --purge -y <package>   # or: dnf remove -y <package>
```
