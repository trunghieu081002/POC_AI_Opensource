# postgres

## trigger
When project.yaml lists `postgres` in components.

## prerequisites
- root or sudo access
- port 5432 available (default)
- ~500MB free in /var/lib/postgresql (Debian) or /var/lib/pgsql (RHEL)

## install (debian)
Install PostgreSQL 15 from the official Postgres apt repo (more stable than distro's).

```bash
apt install -y curl ca-certificates lsb-release gnupg
install -d /usr/share/postgresql-common/pgdg
curl -fsSL -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc https://www.postgresql.org/media/keys/ACCC4CF8.asc
sh -c 'echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
apt update
apt install -y postgresql-15
systemctl enable --now postgresql
```

## install (rhel)
Install PostgreSQL 15 from the PGDG yum repo (works on RHEL/Oracle Linux 8+ and 9).

```bash
dnf install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-$(rpm -E %rhel)-x86_64/pgdg-redhat-repo-latest.noarch.rpm
dnf -qy module disable postgresql
dnf install -y postgresql15-server postgresql15
/usr/pgsql-15/bin/postgresql-15-setup initdb
systemctl enable --now postgresql-15
```

## config
For each database name `db` in `spec.components.postgres.databases`:

```bash
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname = '{{ db }}';" | grep -q 1 || sudo -u postgres psql -c "CREATE DATABASE {{ db }};"
```

(Idempotent: create only if not exists.)

If `spec.components.postgres.users` is set, for each user `{name, password}`:

```bash
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname = '{{ name }}';" | grep -q 1 || sudo -u postgres psql -c "CREATE USER {{ name }} WITH PASSWORD '{{ password }}';"
```

## verify
```bash
sudo -u postgres pg_isready
sudo -u postgres psql -c "SELECT version();"
```

## rollback

Debian:
```bash
systemctl disable --now postgresql
apt remove --purge -y postgresql-15
rm -rf /var/lib/postgresql/15
```

RHEL:
```bash
systemctl disable --now postgresql-15
dnf remove -y postgresql15-server postgresql15
rm -rf /var/lib/pgsql/15
```
