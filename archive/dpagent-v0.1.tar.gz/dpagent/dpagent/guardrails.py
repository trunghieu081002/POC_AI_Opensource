"""Command guardrails: whitelist prefixes (auto-allowed) and blacklist patterns (never)."""
import re
from dataclasses import dataclass


# Commands that don't need per-step confirmation. Extend CAREFULLY.
WHITELIST_PREFIXES = [
    "apt", "apt-get", "dpkg", "add-apt-repository",
    "dnf", "yum", "rpm",
    "systemctl", "service", "journalctl",
    "mkdir", "cp", "mv", "chown", "chmod", "chgrp", "ln", "install",
    "useradd", "usermod", "groupadd", "getent", "id",
    "python3", "python3.11", "python3.12", "pip", "pip3",
    "curl", "wget",
    "tar", "unzip", "gzip", "gunzip",
    "docker", "podman",
    "firewall-cmd", "ufw",
    "sysctl", "modprobe",
    "cat", "grep", "sed", "awk", "tee",
    "test", "[",
    "echo", "true", "false", "sleep",
    "sudo -u postgres",  # postgres role
]

# Absolute blacklist — never run, even if user OKs.
BLACKLIST_PATTERNS = [
    r"\brm\s+-rf?\s+/\s*(?:$|[^\w/])",       # rm -rf / (allow rm -rf /some/path)
    r"\brm\s+-rf?\s+/\*",                     # rm -rf /*
    r"\bdd\s+.*of=/dev/(sd|nvme|vd|xvd|hd)",  # dd to raw disk
    r"\bmkfs\.",                              # any filesystem format
    r">\s*/etc/(passwd|shadow|sudoers)",      # overwrite sensitive files
    r"\bchmod\s+-R\s+777\s+/\s*(?:$|[^\w/])", # chmod -R 777 /
    r":\(\)\s*\{[^}]*\|\s*:\s*\}",            # fork bomb :(){ :|: & };:
    r"(curl|wget)\s+[^|]*\|\s*(sudo\s+)?(bash|sh)\b",  # pipe to shell
    r"\bshutdown\b|\breboot\b|\bhalt\b|\bpoweroff\b",  # power ops
    r"\buserdel\s+-r\s+root\b",
]


@dataclass
class GuardResult:
    ok: bool
    verdict: str        # whitelisted | needs_confirm | blocked
    reason: str


def check(cmd: str) -> GuardResult:
    """Classify a command against guardrails."""
    cmd = cmd.strip()

    for pattern in BLACKLIST_PATTERNS:
        if re.search(pattern, cmd):
            return GuardResult(False, "blocked", f"matches blacklist: {pattern}")

    # Handle sudo wrapping — strip and re-check
    if cmd.startswith("sudo "):
        inner = cmd[5:].strip()
        if inner.startswith("-u ") or inner.startswith("--user="):
            # skip -u user
            parts = inner.split(None, 2)
            if len(parts) >= 3:
                inner = parts[2]
        # first check if the whole sudo-... matches a whitelist prefix (e.g. "sudo -u postgres")
        for prefix in sorted(WHITELIST_PREFIXES, key=len, reverse=True):
            if cmd.startswith(prefix + " ") or cmd == prefix:
                return GuardResult(True, "whitelisted", f"prefix: {prefix}")
        # else recurse on the inner command
        inner_result = check(inner)
        return GuardResult(inner_result.ok, inner_result.verdict, f"sudo→{inner_result.reason}")

    for prefix in sorted(WHITELIST_PREFIXES, key=len, reverse=True):
        if cmd.startswith(prefix + " ") or cmd == prefix:
            return GuardResult(True, "whitelisted", f"prefix: {prefix}")

    return GuardResult(False, "needs_confirm", "no matching whitelist prefix")
