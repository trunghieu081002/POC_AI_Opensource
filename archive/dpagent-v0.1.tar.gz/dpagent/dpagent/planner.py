"""Build an installation plan by giving an LLM the spec, relevant skills, and OS info."""
import yaml
from pathlib import Path
from typing import Any

from . import llm, os_detector


REPO_ROOT = Path(__file__).parent.parent
SKILLS_DIR = REPO_ROOT / "skills"
PROMPTS_DIR = Path(__file__).parent / "prompts"


def _load_skill(name: str) -> str:
    path = SKILLS_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(
            f"Skill not found: {path}. Add skills/{name}.md or copy from skills/_template.md"
        )
    return path.read_text()


def _load_prompt(name: str) -> str:
    path = PROMPTS_DIR / f"{name}.md"
    return path.read_text()


def _components_needed(spec: dict) -> list[str]:
    names: list[str] = []
    for item in spec.get("components", []):
        if isinstance(item, dict):
            names.extend(item.keys())
        elif isinstance(item, str):
            names.append(item)
    return names


def build_plan(spec_path: str, fake_os: dict | None = None) -> tuple[dict, dict]:
    """Return (spec, plan). spec is the parsed yaml; plan is JSON from the LLM.

    fake_os: override OS detection (useful for testing off-target).
    """
    spec: dict[str, Any] = yaml.safe_load(Path(spec_path).read_text())

    if fake_os:
        os_dict = fake_os
    else:
        os_dict = os_detector.detect().as_dict()

    components = _components_needed(spec)
    if not components:
        raise ValueError("spec.components is empty")

    skills_text = ""
    for name in components:
        skills_text += f"\n\n===== SKILL: {name} =====\n{_load_skill(name)}"

    system_prompt = _load_prompt("plan_system")
    user_prompt = f"""OS info:
{os_dict}

Project spec (project.yaml):
```yaml
{yaml.safe_dump(spec, sort_keys=False)}
```

Relevant skills:{skills_text}

Now emit the plan JSON.
"""

    plan = llm.chat_json(system_prompt, user_prompt)
    return spec, plan
