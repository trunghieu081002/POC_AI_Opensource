"""dpagent CLI — plan, apply, verify."""
import sys
import click
from rich.console import Console
from rich.tree import Tree
from rich.panel import Panel

from . import planner, bash_executor, state_store, guardrails, os_detector, llm


console = Console()


@click.group()
@click.version_option("0.1.0")
def main():
    """dpagent — AI agent that installs open-source data stacks."""
    pass


@main.command("info")
def info_cmd():
    """Show detected OS + configured LLM. Doesn't call the LLM."""
    try:
        os_info = os_detector.detect()
        console.print(Panel(str(os_info.as_dict()),
                            title="Target OS", border_style="cyan"))
    except Exception as e:
        console.print(f"[red]OS detect failed:[/red] {e}")

    console.print(Panel(f"model: [bold]{llm.get_model()}[/bold]",
                        title="LLM", border_style="magenta"))


@main.command("plan")
@click.argument("spec_path", type=click.Path(exists=True))
@click.option("--fake-os", type=click.Choice(["ubuntu", "rhel"]),
              help="Skip OS detection, pretend to be this distro (for testing off-target).")
def plan_cmd(spec_path, fake_os):
    """Ask the LLM to build an installation plan from a project spec."""
    console.print(f"[dim]Reading spec:[/dim] {spec_path}")
    console.print(f"[dim]Using model:[/dim] [magenta]{llm.get_model()}[/magenta]")

    fake = None
    if fake_os == "ubuntu":
        fake = {"id": "ubuntu", "family": "debian", "version": "22.04",
                "pkg_mgr": "apt", "svc_mgr": "systemd", "firewall": "ufw"}
    elif fake_os == "rhel":
        fake = {"id": "ol", "family": "rhel", "version": "9",
                "pkg_mgr": "dnf", "svc_mgr": "systemd", "firewall": "firewalld"}

    try:
        spec, plan = planner.build_plan(spec_path, fake_os=fake)
    except Exception as e:
        console.print(f"[red]Planning failed:[/red] {e}")
        sys.exit(1)

    plan_id = state_store.save_plan(spec.get("project", "unnamed"), spec, plan)

    console.print(Panel(
        f"[bold]{plan.get('summary', 'plan')}[/bold]\n[dim]plan_id: {plan_id}[/dim]",
        title="Plan built", border_style="cyan",
    ))

    tree = Tree("[bold]steps[/bold]")
    for step in plan.get("steps", []):
        node = tree.add(
            f"[cyan]{step['id']}[/cyan] · [yellow]{step.get('component', '?')}[/yellow] · "
            f"{step.get('description', '')}"
        )
        node.add(f"[dim]$ [/dim][white]{step['cmd']}[/white]")
        deps = step.get("depends_on", [])
        if deps:
            node.add(f"[dim]depends_on:[/dim] {', '.join(deps)}")
    console.print(tree)

    console.print("\n[dim]Next:[/dim]  dpagent apply --dry-run")


@main.command("apply")
@click.option("--dry-run", is_flag=True, help="Show commands without running them.")
@click.option("--yes", "-y", is_flag=True, help="Skip per-step confirmation.")
def apply_cmd(dry_run, yes):
    """Execute the latest plan step by step."""
    p = state_store.latest_plan()
    if not p:
        console.print("[red]No plan found. Run `dpagent plan <spec>` first.[/red]")
        sys.exit(1)

    console.print(f"[bold]Applying plan {p['id']}[/bold] · {p['project']}"
                  + (" [yellow](DRY-RUN)[/yellow]" if dry_run else ""))

    for step in p["steps"]:
        if step["status"] == "done":
            console.print(f"[green]✓[/green] {step['step_id']} (already done, skipping)")
            continue

        console.print(f"\n[cyan]{step['step_id']}[/cyan] · {step['description']}")
        console.print(f"  [dim]$[/dim] {step['cmd']}")

        guard = guardrails.check(step["cmd"])
        if guard.verdict == "blocked":
            console.print(f"  [red]BLOCKED:[/red] {guard.reason}")
            state_store.mark_step(step["id"], "failed", {"guard": guard.reason})
            sys.exit(2)

        if guard.verdict == "needs_confirm" and not yes:
            if not click.confirm(f"  needs confirmation ({guard.reason}). Run?"):
                state_store.mark_step(step["id"], "skipped", {"reason": "user declined"})
                continue

        result = bash_executor.run(step["cmd"], dry_run=dry_run,
                                    run_id=f"plan-{p['id']}")

        if result.returncode == 0:
            console.print(f"  [green]OK[/green] ({result.duration_ms}ms)")
            state_store.mark_step(step["id"], "done",
                                   {"rc": 0, "duration_ms": result.duration_ms})
        else:
            console.print(f"  [red]FAIL[/red] rc={result.returncode}")
            if result.stderr:
                console.print(f"  [red]stderr:[/red] {result.stderr[:500]}")
            state_store.mark_step(step["id"], "failed",
                                   {"rc": result.returncode,
                                    "stderr": result.stderr[:1000]})
            console.print(f"\n[yellow]Plan halted at {step['step_id']}. "
                          f"Fix and re-run `dpagent apply` to continue.[/yellow]")
            sys.exit(3)

    console.print("\n[bold green]All steps done.[/bold green]")


@main.command("verify")
def verify_cmd():
    """Run health checks (parses skills' verify section — coming in v0.2)."""
    console.print("[yellow]verify:[/yellow] not implemented in v0.1 — "
                  "parse the [dim]## verify[/dim] section of installed skills.")


if __name__ == "__main__":
    main()
