"""Detect the target OS: distro family, package manager, service manager, firewall."""
import re
from pathlib import Path
from dataclasses import dataclass, asdict


@dataclass
class OSInfo:
    id: str          # ubuntu, ol, rhel, debian, ...
    family: str      # "debian" or "rhel"
    version: str
    pkg_mgr: str     # apt or dnf
    svc_mgr: str = "systemd"
    firewall: str = "firewalld"

    def as_dict(self) -> dict:
        return asdict(self)


DEBIAN_LIKE = {"debian", "ubuntu", "linuxmint", "pop"}
RHEL_LIKE = {"rhel", "centos", "ol", "rocky", "almalinux", "fedora"}


def detect() -> OSInfo:
    """Read /etc/os-release and derive the info we need."""
    path = Path("/etc/os-release")
    if not path.exists():
        raise RuntimeError("/etc/os-release not found — is this a Linux host?")

    kv: dict[str, str] = {}
    for line in path.read_text().splitlines():
        m = re.match(r"^([A-Z_]+)=(.*)$", line.strip())
        if m:
            kv[m.group(1)] = m.group(2).strip('"').strip("'")

    os_id = kv.get("ID", "unknown").lower()
    version = kv.get("VERSION_ID", "unknown")
    id_like = kv.get("ID_LIKE", "").lower()

    if os_id in DEBIAN_LIKE or "debian" in id_like:
        return OSInfo(id=os_id, family="debian", version=version,
                      pkg_mgr="apt", firewall="ufw")
    if os_id in RHEL_LIKE or "rhel" in id_like or "fedora" in id_like:
        return OSInfo(id=os_id, family="rhel", version=version,
                      pkg_mgr="dnf", firewall="firewalld")

    raise RuntimeError(
        f"Unsupported distro: {os_id}. Supported: {sorted(DEBIAN_LIKE | RHEL_LIKE)}"
    )
