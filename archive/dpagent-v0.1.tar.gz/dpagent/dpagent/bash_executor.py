"""Execute shell commands with guardrails, dry-run, and structured logging."""
import subprocess
import json
import time
import os
from pathlib import Path
from dataclasses import dataclass, asdict
from .guardrails import check as check_guard


LOG_DIR = Path(os.getenv("DPAGENT_LOG_DIR", str(Path.home() / ".local/share/dpagent/log")))


@dataclass
class ExecResult:
    cmd: str
    returncode: int
    stdout: str
    stderr: str
    duration_ms: int
    guard: dict


def _ensure_log_dir() -> Path:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        return LOG_DIR
    except PermissionError:
        alt = Path.home() / ".local/share/dpagent/log"
        alt.mkdir(parents=True, exist_ok=True)
        return alt


def run(cmd: str, dry_run: bool = False, timeout: int = 600,
        run_id: str = "default") -> ExecResult:
    """Run a shell command, honoring guardrails.

    Raises PermissionError if the command hits the blacklist.
    Never raises for normal non-zero exit — inspect .returncode instead.
    """
    guard = check_guard(cmd)

    if guard.verdict == "blocked":
        raise PermissionError(f"BLACKLISTED: {cmd}\n  {guard.reason}")

    if dry_run:
        return ExecResult(
            cmd=cmd, returncode=0,
            stdout=f"[DRY-RUN] would run: {cmd}",
            stderr="", duration_ms=0, guard=asdict(guard),
        )

    log_dir = _ensure_log_dir()
    log_path = log_dir / f"run-{run_id}.jsonl"

    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout,
        )
        dt = int((time.time() - t0) * 1000)
        result = ExecResult(
            cmd=cmd, returncode=proc.returncode,
            stdout=proc.stdout, stderr=proc.stderr,
            duration_ms=dt, guard=asdict(guard),
        )
    except subprocess.TimeoutExpired:
        dt = int((time.time() - t0) * 1000)
        result = ExecResult(
            cmd=cmd, returncode=-1, stdout="",
            stderr=f"TIMEOUT after {timeout}s",
            duration_ms=dt, guard=asdict(guard),
        )

    with log_path.open("a") as f:
        f.write(json.dumps({
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            **asdict(result),
        }) + "\n")

    return result
