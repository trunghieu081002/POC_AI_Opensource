"""LLM client — provider agnostic via LiteLLM.

Swap providers by setting DPAGENT_MODEL. Free / cheap options first:

  # Google Gemini — very generous free tier (1500 req/day)
  DPAGENT_MODEL=gemini/gemini-2.0-flash
  GEMINI_API_KEY=...

  # Groq — free tier, very fast Llama
  DPAGENT_MODEL=groq/llama-3.3-70b-versatile
  GROQ_API_KEY=...

  # OpenRouter (routes to many providers, some free)
  DPAGENT_MODEL=openrouter/deepseek/deepseek-chat
  OPENROUTER_API_KEY=...

  # Ollama — local, truly free (needs GPU or lots of RAM)
  DPAGENT_MODEL=ollama/qwen2.5-coder:32b

  # OpenAI (any GPT model in your account)
  DPAGENT_MODEL=openai/gpt-4o-mini            # ~$0.15/1M input
  DPAGENT_MODEL=openai/gpt-5-mini             # if you have access
  OPENAI_API_KEY=...

  # Anthropic
  DPAGENT_MODEL=anthropic/claude-sonnet-4-5
  ANTHROPIC_API_KEY=...
"""
import os
import json
from typing import Any
import litellm

# Uncomment for verbose debugging:
# litellm.set_verbose = True

DEFAULT_MODEL = "gemini/gemini-2.0-flash"


def get_model() -> str:
    return os.getenv("DPAGENT_MODEL", DEFAULT_MODEL)


def chat_json(system: str, user: str, model: str | None = None,
              temperature: float = 0.2, max_tokens: int = 8000) -> dict[str, Any]:
    """Send a chat request and return parsed JSON.

    Tries response_format=json_object first, falls back to prompt-only JSON.
    Also strips ```json fences if the model adds them.
    """
    model = model or get_model()
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    try:
        response = litellm.completion(**kwargs, response_format={"type": "json_object"})
    except Exception:
        response = litellm.completion(**kwargs)

    content = (response.choices[0].message.content or "").strip()

    if content.startswith("```"):
        content = content.split("```", 2)[1]
        if content.startswith("json"):
            content = content[4:]
        content = content.strip("` \n")

    return json.loads(content)


def chat_text(system: str, user: str, model: str | None = None,
              temperature: float = 0.2, max_tokens: int = 4000) -> str:
    """Send a chat request and return raw text."""
    model = model or get_model()
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]
    response = litellm.completion(
        model=model, messages=messages, temperature=temperature, max_tokens=max_tokens
    )
    return response.choices[0].message.content or ""
