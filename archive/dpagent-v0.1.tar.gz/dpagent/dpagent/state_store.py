"""SQLite-backed state for plans, steps, and checkpoints."""
import sqlite3
import json
import os
from pathlib import Path
from datetime import datetime


DB_PATH = Path(os.getenv("DPAGENT_DB", str(Path.home() / ".local/share/dpagent/state.db")))


SCHEMA = """
CREATE TABLE IF NOT EXISTS plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    project TEXT NOT NULL,
    spec_json TEXT NOT NULL,
    plan_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id INTEGER NOT NULL,
    step_id TEXT NOT NULL,
    component TEXT,
    description TEXT,
    cmd TEXT NOT NULL,
    depends_on TEXT,
    status TEXT DEFAULT 'pending',
    result_json TEXT,
    checkpoint_at TEXT,
    FOREIGN KEY(plan_id) REFERENCES plans(id)
);
CREATE INDEX IF NOT EXISTS idx_steps_plan ON steps(plan_id);
"""


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def save_plan(project: str, spec: dict, plan: dict) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO plans (created_at, project, spec_json, plan_json) VALUES (?, ?, ?, ?)",
            (datetime.utcnow().isoformat(), project, json.dumps(spec), json.dumps(plan)),
        )
        plan_id = cur.lastrowid
        for step in plan.get("steps", []):
            c.execute(
                """INSERT INTO steps
                       (plan_id, step_id, component, description, cmd, depends_on)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (plan_id, step["id"], step.get("component"),
                 step.get("description"), step["cmd"],
                 json.dumps(step.get("depends_on", []))),
            )
        return plan_id


def latest_plan() -> dict | None:
    with _conn() as c:
        row = c.execute(
            "SELECT * FROM plans ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        steps = c.execute(
            "SELECT * FROM steps WHERE plan_id = ? ORDER BY id",
            (row["id"],),
        ).fetchall()
        return {
            "id": row["id"], "project": row["project"],
            "created_at": row["created_at"],
            "spec": json.loads(row["spec_json"]),
            "plan": json.loads(row["plan_json"]),
            "steps": [dict(s) for s in steps],
        }


def mark_step(step_pk: int, status: str, result: dict | None = None) -> None:
    with _conn() as c:
        c.execute(
            "UPDATE steps SET status = ?, result_json = ?, checkpoint_at = ? WHERE id = ?",
            (status, json.dumps(result or {}),
             datetime.utcnow().isoformat(), step_pk),
        )
