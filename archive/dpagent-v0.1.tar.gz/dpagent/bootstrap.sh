#!/usr/bin/env bash
# Bootstrap dpagent on a target server.
# Usage:
#   sudo bash bootstrap.sh
#   # or, when the repo is hosted somewhere reachable:
#   curl -fsSL https://<host>/dpagent/bootstrap.sh | sudo bash
set -euo pipefail

REPO_URL="${DPAGENT_REPO:-https://github.com/YOUR_ORG/dpagent.git}"
INSTALL_DIR="/opt/dpagent"

echo "[*] Installing prerequisites"
if command -v apt >/dev/null 2>&1; then
    apt update
    apt install -y python3 python3-venv python3-pip git
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip git
else
    echo "Unsupported package manager (need apt or dnf)"
    exit 1
fi

echo "[*] Cloning dpagent to $INSTALL_DIR"
if [ ! -d "$INSTALL_DIR" ]; then
    git clone "$REPO_URL" "$INSTALL_DIR"
else
    (cd "$INSTALL_DIR" && git pull)
fi

echo "[*] Setting up venv"
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install -e "$INSTALL_DIR"

echo "[*] Linking dpagent CLI"
ln -sf "$INSTALL_DIR/venv/bin/dpagent" /usr/local/bin/dpagent

echo ""
echo "[OK] dpagent installed. Next:"
echo "     1) Choose a free LLM and set it, e.g.:"
echo "          export DPAGENT_MODEL=gemini/gemini-2.0-flash"
echo "          export GEMINI_API_KEY=<your-key>"
echo "     2) Sanity check: dpagent info"
echo "     3) Try a plan:  dpagent plan $INSTALL_DIR/examples/postgres-only.yaml"
